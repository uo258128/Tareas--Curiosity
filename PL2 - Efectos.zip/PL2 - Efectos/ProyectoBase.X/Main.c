/*
 * 
 * 
 * ESTE ES EL SEGUNDO EJERCICIO: EFECTOS DE LOS LEDS
 * 
 * 
 * 
 * File:   Main.c
 * Author: SEA - Aitor VA
 * D.E.P. - GiTELE - 2019-2020
 */

/* 
 * File:   Main.c
 * Author: AVA

 */

/* Este proyecto tiene como objetivo proveer los archivos base y la estructura
 * T�pica de programaci�n para usar durante la asignatura. L�ease con atenci�n
 * las recomendaciones y las instrucciones de uso.
 */

// SIEMPRE SE INCLUIR�N ESTOS ARCHIVOS DE CABECERA:
#include "Func.h"
#include "Func.c"
#include <stdio.h>
#include <stdlib.h>
#include <xc.h>
#include <libpic30.h>


//---------------------------------------------------------------------------
// Global variables
//---------------------------------------------------------------------------
// En este espacio pueden declararse las variables globales o las constantes.
// Ejemplo:
// unsigned int MiValor = 0;


//---------------------------------------------------------------------------
// ISR routine
//---------------------------------------------------------------------------

// Llamada a la subrutina de interrupci�n. Descomentar estas l�neas para activarla.
// Debe incluirse el nombre de la rutina de interrupci�n (vector de interrupci�n).
// Esta llamada a la funci�n de interrupci�n debe repetirse tantas veces como
// vectores de interrupci�n haya (cada una, con su vector correspondiente)


//Diapositiva 98 - MPLAB� XC16 ISR Name

/*
void __attribute__((interrupt, auto_psv)) _T1Interrupt(void)
//{
    
//}

        IPC0bits.T1IP = 3;

*/
//---------------------------------------------------------------------------
// Main routine
//---------------------------------------------------------------------------

// Funci�n principal. Siempre incluye un bucle infinito.

int main (void)
{   
    // Aqu� se declarar�an las variables LOCALES a la funci�n Main.
       
    InitIO();
    
    while (1)
    {
       /* __delay_ms(500);
        LATEbits.LATE0 =! LATEbits.LATE0;
        LATEbits.LATE1 =! LATEbits.LATE1;
        LATBbits.LATB14 =! LATBbits.LATB14;
        LATDbits.LATD7 =! LATDbits.LATD7;
        LATDbits.LATD5 =! LATDbits.LATD5;
        * 
        * */
    
    
    unsigned int casos = 0;
    unsigned int i;
    
    casos++;
    
    if (IFS0bits.T1IF == 1){
           
        
    IFS0bits.T1IF=0;  //Limpiar FLAG de interrupcion del TMR1    
    
               
   
        if(casos>=1 && casos<=5) Efecto1(casos-1);
    
        if(casos>=6 && casos<=15) Efecto2(casos-6);
    
        if(casos==16) {
            casos=0;
            i=0;}
    }
    }
}//MAIN
   

