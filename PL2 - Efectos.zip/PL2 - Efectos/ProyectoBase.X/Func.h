/* 
 * File:   Func.h
 * Author: AVA
 *
 */

/* En este archivo deben incluirse los prototipos de las funciones utilizadas en
 * FUNC.C.
 */

#ifndef FUNC_H
#define	FUNC_H


#define FCY = (4000000)
#include <libpic30.h>


// EJEMPLO:
void InitIO(void);
void Efecto1(unsigned int);
void Efecto2(unsigned int);
void ConfigInt();



#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* FUNC_H */


