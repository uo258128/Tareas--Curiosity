/*
 * File:   func.h
 * Author: danie
 *
 * Created on March 30, 2022, 11:26 PM
 */


#include "xc.h"

int main(void) {
    return 0;
}
