/**
 * 
 * 
 * CON LA INTERRUPCI�N DEL TIMER VOY GENERANDO EL TIEMPO DE LOS EFECTOS
 * 
 * CON LOS SWITCHES VAR�O LOS EFECTOS
 * 
 * TAMBI�N VOY A VARIAR EL TIEMPO DE PARPADEO
 * 
 * 
 * A MODO RESUMEN: switch1 me var�a los efectos y sw2 la velocidad, el sw3 desactiva brevemente los leds.
 * 
 * 
 * 
 * 
 * 
  Generated main.c file from MPLAB Code Configurator

  @Company
    Microchip Technology Inc.

  @File Name
    main.c

  @Summary
    This is the generated main.c using PIC24 / dsPIC33 / PIC32MM MCUs.

  @Description
    This source file provides main entry point for system initialization and application code development.
    Generation Information :
        Product Revision  :  PIC24 / dsPIC33 / PIC32MM MCUs - 1.171.1
        Device            :  dsPIC33CH512MP508
    The generated drivers are tested against the following:
        Compiler          :  XC16 v1.70
        MPLAB 	          :  MPLAB X v5.50
*/

/*
    (c) 2020 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
*/

/**
  Section: Included Files
*/
#include "mcc_generated_files/system.h"
#include "mcc_generated_files/mcc.h"
#include "mcc_generated_files/pin_manager.h"
#define FCY  8000000UL
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <xc.h>
#include <libpic30.h>
#include "func.h"

/*
                         Main application
 */

            
unsigned int casos = 0;
unsigned int casos1=0;
unsigned int casos2=0;
unsigned int efecto = 0;
unsigned int contadorSW = 1;
unsigned int AUXcontador = 1;
    
void T1Interrupt(void)
{
    
    //voy a usar el switch1
    
    //dependiendo de si lo mantienes pulsado o no var�a los efectos.
    
    /*
    if(PORTEbits.RE7==0){
        casos1++;
        if(casos1==6)casos1=0;
        Efecto1(casos1-1);
        
    }else{
        casos2++;
        if(casos2==11)casos2=0;
        Efecto2(casos2-1);
        
    }
    */
    
    //IFS0bits.T1IF = 0;  //Limpiar FLAG de interrupcion del TMR1
    
                casos++;
            if (casos==11){
                casos=0;
            }
             switch(efecto){
            case 0:
                Efecto0();
            break;
            
            case 1:
                Efecto1(casos);
            break;
            
            case 2: 
                Efecto2(casos);
            break;
            
            default:
                Efecto0();
            break;    
                             
            }
            CambioPR1(contadorSW);
    
}


void SW1Interrupt(void){
    
    //la interrupci�n que me va a cambiar los efectos
    
    //IFS1bits.INT1IF = 0;
        
    efecto++;
    if (efecto==3){
        efecto=0;
        casos=0;
        
        LATEbits.LATE0 = 0;
		LATEbits.LATE1 = 0;
		LATBbits.LATB14=0;
		LATDbits.LATD7=0;
		LATDbits.LATD5=0;
        
    }
}

void SW2Interrupt(void){
    
    //IFS2bits.INT4IF = 0;
    
    contadorSW++;
    
    if(contadorSW == 5){
        contadorSW= 1;
    }
}

void SW3Interrupt(void){
    
    //IFS2bits.INT4IF = 0;
    
    //si pulso el sw3 se apaga todo durante el tiempo que est� programado el PR1
    
    LATEbits.LATE0 = 0;
	LATEbits.LATE1 = 0;
	LATBbits.LATB14 = 0;
	LATDbits.LATD7 = 0;
	LATDbits.LATD5 = 0;
    

}
    
int main(void)
{
    // initialize the device
    SYSTEM_Initialize();

    //ConfigInt();
    TMR1_SetInterruptHandler(T1Interrupt);
    IO_RE7_SetInterruptHandler(SW1Interrupt);
    IO_RE8_SetInterruptHandler(SW2Interrupt);
    IO_RE9_SetInterruptHandler(SW3Interrupt);
    
    TMR1_Start();
     
    while (1)
    {
        // Add your application code
 
    }
    return 1; 
}