
/**
  Section: Included Files
*/
#include "mcc_generated_files/system.h"
#include "mcc_generated_files/mcc.h"
#include "mcc_generated_files/pin_manager.h"
#include "mcc_generated_files/LCDMiniDrivers/lcd.h"
#define FCY  8000000UL
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <xc.h>
#include <libpic30.h>


// Programa que va a mostrar por pantalla la tensi�n del potenci�metro por el LCD

uint8_t row0[16];
uint8_t row1[16];
        
uint8_t* prow0 = &row0;
uint8_t* prow1 = &row1;

char fila0[16];
char fila1[16];


void T1Interrupt(void)
{
      
    IFS0bits.T1IF=0;
     
    //Voy a usar la interrupci�n del timer para imprimir la info del CAD
    
    ADC1_SoftwareTriggerEnable();
    
    //Siempre se pone. Debe ser por el tiempo de adquisici�n.
    int i;
    
        for(i=0;i <1000;i++)
        {
        }
    
    ADC1_SoftwareTriggerDisable();
    
    
    //Para almacenar la conversion de lo que ve en el potenci�metro
    while(!ADC1_IsConversionComplete(POTEAN0)); //del adcbuf0 ser�.
    //Guardada info
      
    float salida; //Variable que va a contener los voltios
    salida = (ADC1_ConversionResultGet(POTEAN0))*5.0/4095.0; // La info que me da el cad, llega hasta 4095, as� que lo paso a voltios.
    
    sprintf(fila0, "LA TENSION SON :");
    sprintf(fila1, " %.3f  voltios", salida); //Lo saco por pantalla con solamente tres decimales.
        
    prow0 = (uint8_t*) &fila0;
    prow1 = (uint8_t*) &fila1;
           
    lcd_writeString(prow0, 0);
    lcd_writeString(prow1, 1);    
    
    }
    
    
int main(void)
{
    // initialize the device
   
    SYSTEM_Initialize();
    
    lcd_setContrast(0x20);
 
    //ConfigInt();

    ADC1_Initialize(); //est� en el system Initialize.
    
    ADC1_InterruptFlagClear();
    ADC1_InterruptEnable();
    
    TMR1_SetInterruptHandler(T1Interrupt); // Aqu� imprime por pantalla.
    TMR1_Start();
    

     
    while (1)
    {
        // Add your application code
        
        
 
    }
    return 1; 
}