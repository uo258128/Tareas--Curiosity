/*
 * File:   func.c
 * Author: danie
 *
 * Created on March 30, 2022, 11:25 PM
 */


#include "xc.h"

#include <p33CH512MP508.h>

#include "main.h"

#include "func.h"

void InitIO(){

//Configuramos leds como salidas

    TRISEbits.TRISE0 = 0;
    TRISEbits.TRISE1 = 0;
    TRISBbits.TRISB14 = 0;
    TRISDbits.TRISD7 = 0;
    TRISDbits.TRISD5 = 0;
    
// Como puse en la hoja, aqu� los inicializo al rev�s.

    LATEbits.LATE0=0;
    LATEbits.LATE1=0;
    LATBbits.LATB14=0;
    LATDbits.LATD7=0;
    LATDbits.LATD5=0;
   
}

void Efecto0()
{
    LATEbits.LATE0 = !LATEbits.LATE0;
    LATEbits.LATE1 = !LATEbits.LATE1;
    LATBbits.LATB14 = !LATBbits.LATB14;
    LATDbits.LATD7 = !LATDbits.LATD7;
    LATDbits.LATD5 = !LATDbits.LATD5;
            
    return;
}//fin efecto0

void Efecto1(unsigned int aux)
{
    switch(aux){
       case 0:
           
         LATEbits.LATE0 = 1;
         LATEbits.LATE1 = 0;
		 LATBbits.LATB14=0;
		 LATDbits.LATD7=0;
		 LATDbits.LATD5=0;
       
       break;
       case 1:
           
           LATEbits.LATE1 = 1;
         LATEbits.LATE0 = 0;
			 LATBbits.LATB14=0;
		 LATDbits.LATD7=0;
		 LATDbits.LATD5=0;
           
       break;
       case 2:
           
         LATBbits.LATB14 = 1;
         LATEbits.LATE0 = 0;
		 LATEbits.LATE1 = 0;
		 LATDbits.LATD7=0;
		 LATDbits.LATD5=0;
       break;
       
       case 3:
          
         LATDbits.LATD7 = 1;
         LATEbits.LATE0 = 0;
		 LATEbits.LATE1 = 0;
		 LATBbits.LATB14=0;
		 LATDbits.LATD5=0;
         
	   break;
       
       case 4:
           
         LATEbits.LATE0 = 0;
		 LATEbits.LATE1 = 0;
		 LATBbits.LATB14=0;
		 LATDbits.LATD7=0;           
         LATDbits.LATD5 = 1;
         
	   break;
     
     default:
         LATEbits.LATE0 = 0;
		 LATEbits.LATE1 = 0;
		 LATBbits.LATB14=0;
		 LATDbits.LATD7=0;
		 LATDbits.LATD5=0;
    }
    return;
}//fin efecto1


    


void Efecto2(unsigned int aux)
{
    switch(cont){   //Vamos a probar a que en cada caso se pueda poner m�s de una orden
       case 0:
	       LATEbits.LATE0 = 1;
	 break;
       
       case 1:
		 LATEbits.LATE0 = 1;
		 LATEbits.LATE1 = 1;
	 break;

	 case 2:
		 LATEbits.LATE0 = 1;
		 LATEbits.LATE1 = 1;
		 LATBbits.LATB14=1;
	 break;

       case 3:
		 LATEbits.LATE0 = 1;
		 LATEbits.LATE1 = 1;
		 LATBbits.LATB14=1;
		 LATDbits.LATD7=1;
       break;

       case 4:
		 LATEbits.LATE0 = 1;
		 LATEbits.LATE1 = 1;
		 LATBbits.LATB14=1;
		 LATDbits.LATD7=1;
		 LATDbits.LATD5=1;
       break;

       case 5:
		 LATEbits.LATE0 = 1;
		 LATEbits.LATE1 = 1;
		 LATBbits.LATB14=1;
		 LATDbits.LATD7=1;
		 LATDbits.LATD5=0;
       break;

       case 6:
		 LATEbits.LATE0 = 1;
		 LATEbits.LATE1 = 1;
		 LATBbits.LATB14=1;
		 LATDbits.LATD7=0;
		 LATDbits.LATD5=0;
       break;

       case 7:
		 LATEbits.LATE0 = 1;
		 LATEbits.LATE1 = 1;
		 LATBbits.LATB14=0;
		 LATDbits.LATD7=0;
		 LATDbits.LATD5=0;
	 break;

       case 8:
		 LATEbits.LATE0 = 1;
		 LATEbits.LATE1 = 0;
		 LATBbits.LATB14=0;
		 LATDbits.LATD7=0;
		 LATDbits.LATD5=0;
       break;

	 case 9:
		 LATEbits.LATE0 = 0;
		 LATEbits.LATE1 = 0;
		 LATBbits.LATB14=0;
		 LATDbits.LATD7=0;
		 LATDbits.LATD5=0;
       break;
       

	 default:
		 LATEbits.LATE0 = 0;
		 LATEbits.LATE1 = 0;
		 LATBbits.LATB14=0;
		 LATDbits.LATD7=0;
		 LATDbits.LATD5=0;
    }
    return;
}//fin efecto2   

//falta efecto2_bis


void ConfigInt()
{
    // Configuring the interrupts
    INTCON1bits.NSTDIS = 1;         // Igual que el el dsPICDem, a uno disabled
    
    IFS0bits.INT0IF = 0;              
    IEC0bits.INT0IE= 1;              
    IPC0bits.INT0IP = 2;              
    
    IPCS0bits.INT1IP = 12;  //primero siempre la prioridad
    IFS0bits.INT1IF = 15;  // limpiar el flag
    IEC0bits.INT1IE = 15;  // habilitar la m�scara de interrupci�n
    
    SET_CPU_IPL(1);                 // Set CPU priority level to a value below the lowest interrupt
    
    return;   
}

void PR1TMR1()
{
    PR1= (FCY/256)/2;
    
    return;
}


void CambioPR1(unsigned int cont){
    
    float tiempofijo = (FCY/256)/2;
    PR1 = tiempofijo*cont;
    
    return;
}

