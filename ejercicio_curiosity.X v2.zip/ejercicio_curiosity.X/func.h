/*
 * File:   func.h
 * Author: danie
 *
 * Created on March 30, 2022, 11:26 PM
 */


#include "xc.h"

void InitIO();
void Efecto0();
void Efecto1(unsigned int);
void Efecto2(unsigned int);
//falta efecto2_bis
void ConfigInt();
void PR1TMR1();
void CambioPR1(unsigned int);
