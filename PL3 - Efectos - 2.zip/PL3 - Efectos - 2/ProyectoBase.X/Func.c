#include <p33CH512MP508.h>
#include "Func.h"
#include <stdio.h>
#include <stdlib.h>
#include <xc.h>
#include <libpic30.h>

/* Este archivo contendr� la definici�n de las funciones auxiliares que se
 * necesiten para la ejecuci�n del c�digo.
 * Pueden a�adirse tantas como se quiera.
 * El objetivo es encapsular lo m�ximo posible el c�digo y reutilizar todas las+
 * funciones posibles.
 * En el archivo FUNC.H deber�n incluirse los prototipos de estas funciones.
 */

// Ejemplo:
// FUNCI�N PARA INICIALIZACI�N DE PUERTOS E/S
// Par�metros de entrada: ninguno (void).
// Par�metros de salida: ninguno (void).

void InitIO(){
    //Configuramos leds como salidas

    TRISEbits.TRISE0 = 0;
    TRISEbits.TRISE1 = 0;
    TRISBbits.TRISB14 = 0;
    TRISDbits.TRISD7 = 0;
    TRISDbits.TRISD5 = 0;
    
// Como puse en la hoja, aqu� los inicializo al rev�s.

    LATEbits.LATE0=0;
    LATEbits.LATE1=0;
    LATBbits.LATB14=0;
    LATDbits.LATD7=0;
    LATDbits.LATD5=0;

    
// ARRANCO TIMER1
    
    T1CON = 0;   //Limpiar el registro de control
    TMR1 = 0;    //Arrancamos el TMR1 a 0
    PR1 = 0x1E84;   //(FCY/256)/2;=7812.5 -> 7812 -> HEX 0X1E84   //Establecer el periodo de temporizacion en 500ms
    T1CON = 0x8030;  //Configuracion del registro T1CON para: TMR1 ON, COntinue IDLE, 
    
    

    return;
}// InitIO

void Efecto1(unsigned int aux){
    switch(aux){
       case 0:LATEbits.LATE0 = 1;
       break;
       
       case 1:
           LATEbits.LATE1 = 1;
           LATEbits.LATE0 = 0;
       break;
       
       case 2:
           LATBbits.LATB14 = 1;
           LATEbits.LATE0 = 0;
           LATEbits.LATE1 = 0;
       break;
       case 3:
           LATDbits.LATD7 = 1;
           LATEbits.LATE0 = 0;
           LATEbits.LATE1 = 0;
           LATBbits.LATB14 = 0;
	 break;
       case 4:
           
           LATDbits.LATD5 = 1;
           LATEbits.LATE0 = 0;
           LATEbits.LATE1 = 0;
           LATDbits.LATD7 = 0;
           LATBbits.LATB14 = 0;
       
	 break;
     
      default:
          
         LATEbits.LATE0 = 0;
		 LATEbits.LATE1 = 0;
		 LATBbits.LATB14=0;
		 LATDbits.LATD7=0;
		 LATDbits.LATD5=0;
    }
    return;
}


void Efecto2(unsigned int aux){
    switch(aux){   //Vamos a probar a que en cada caso se pueda poner m�s de una orden
       case 0:
	       LATEbits.LATE0 = 1;
	 break;
       
       case 1:
		 LATEbits.LATE0 = 1;
		 LATEbits.LATE1 = 1;
	 break;

	 case 2:
		 LATEbits.LATE0 = 1;
		 LATEbits.LATE1 = 1;
		 LATBbits.LATB14=1;
	 break;

       case 3:
		 LATEbits.LATE0 = 1;
		 LATEbits.LATE1 = 1;
		 LATBbits.LATB14=1;
		 LATDbits.LATD7=1;
       break;

       case 4:
		 LATEbits.LATE0 = 1;
		 LATEbits.LATE1 = 1;
		 LATBbits.LATB14=1;
		 LATDbits.LATD7=1;
		 LATDbits.LATD5=1;
       break;

       case 5:
		 LATEbits.LATE0 = 1;
		 LATEbits.LATE1 = 1;
		 LATBbits.LATB14=1;
		 LATDbits.LATD7=1;
		 LATDbits.LATD5=0;
       break;

       case 6:
		 LATEbits.LATE0 = 1;
		 LATEbits.LATE1 = 1;
		 LATBbits.LATB14=1;
		 LATDbits.LATD7=0;
		 LATDbits.LATD5=0;
       break;

       case 7:
		 LATEbits.LATE0 = 1;
		 LATEbits.LATE1 = 1;
		 LATBbits.LATB14 = 0;
		 LATDbits.LATD7=0;
		 LATDbits.LATD5=0;
	 break;

       case 8:
		 LATEbits.LATE0 = 1;
		 LATEbits.LATE1 = 0;
		 LATBbits.LATB14=0;
		 LATDbits.LATD7=0;
		 LATDbits.LATD5=0;
       break;

	 case 9:
		 LATEbits.LATE0 = 0;
		 LATEbits.LATE1 = 0;
		 LATBbits.LATB14=0;
		 LATDbits.LATD7=0;
		 LATDbits.LATD5=0;
       break;
       

	 default:
		 LATEbits.LATE0 = 0;
		 LATEbits.LATE1 = 0;
		 LATBbits.LATB14=0;
		 LATDbits.LATD7=0;
		 LATDbits.LATD5=0;
    }
    return;
}   

/*
void Efecto2_bis(unsigned int desplaza){
    switch(desplaza){
        case 0:LATD = ((PORTD<<1) &  0xFFFE);  //Se van metiendo "0s" ->Enciende LEDs
        break;
        case 1:LATD = ((PORTD>>1) |  0x0008);  //Se van metiendo "1s" ->Apago LEDs
        break;
    }
    return;
}
 * 
 * //
 * 
*/


void ConfigInt(){
    // Configuring the interrupts
    INTCON1bits.NSTDIS = 1;         // Disable nesting interrputs 
    
    
    //ver tabla p�gina 102 y 103 para la prioridad.
    
    IEC0bits.T1IE = 1;
    IFS0bits.T1IF = 0;
    IPC0bits.T1IP = 3;

        
    SET_CPU_IPL(1);                 // Set CPU priority level to a value below the lowest interrupt
    
    return;   
}



