/*
 * 
 * 
 * ESTE ES EL TERCER EJERCICIO: LOS EFECTOS DE LOS LEDS CAMBIAR�N
 *         DEPENDIENDO SI TENEMOS PULSADO UN SWITCH O NO.
 * 
 * 
 * 
 * File:   Main.c
 * Author: SEA - Aitor VA
 * D.E.P. - GiTELE - 2019-2020
 */

/* 
 * File:   Main.c
 * Author: AVA

 */

/* Este proyecto tiene como objetivo proveer los archivos base y la estructura
 * T�pica de programaci�n para usar durante la asignatura. L�ease con atenci�n
 * las recomendaciones y las instrucciones de uso.
 */

// SIEMPRE SE INCLUIR�N ESTOS ARCHIVOS DE CABECERA:
#include "Func.h"
#include "Func.c"
#include <stdio.h>
#include <stdlib.h>
#include <xc.h>
#include <libpic30.h>


//---------------------------------------------------------------------------
// Global variables
//---------------------------------------------------------------------------
// En este espacio pueden declararse las variables globales o las constantes.
// Ejemplo:
// unsigned int MiValor = 0;

unsigned int casos1=0;
unsigned int casos2=0;

//---------------------------------------------------------------------------
// ISR routine
//---------------------------------------------------------------------------

// Llamada a la subrutina de interrupci�n. Descomentar estas l�neas para activarla.
// Debe incluirse el nombre de la rutina de interrupci�n (vector de interrupci�n).
// Esta llamada a la funci�n de interrupci�n debe repetirse tantas veces como
// vectores de interrupci�n haya (cada una, con su vector correspondiente)


//Diapositiva 98 - MPLAB� XC16 ISR Name


void  T1Interrupt(void)
{
    
    //voy a usar el switch1
    
    if(PORTEbits.RE7==0){
        casos1++;
        Efecto1(casos1-1);
        if(casos1==6)casos1=0;
    }else{
        casos2++;
        Efecto2(casos2-1);
        if(casos2==11)casos2=0;
    }
    
}

//---------------------------------------------------------------------------
// Main routine
//---------------------------------------------------------------------------

// Funci�n principal. Siempre incluye un bucle infinito.

int main (void)
{   
    // Aqu� se declarar�an las variables LOCALES a la funci�n Main.
       
    InitIO();
    ConfigInt();
   
    void T1Interrupt(void);
    
    while (1)
    {
       /* __delay_ms(500);
        LATEbits.LATE0 =! LATEbits.LATE0;
        LATEbits.LATE1 =! LATEbits.LATE1;
        LATBbits.LATB14 =! LATBbits.LATB14;
        LATDbits.LATD7 =! LATDbits.LATD7;
        LATDbits.LATD5 =! LATDbits.LATD5;
        * 
        * */
    
    /*
    unsigned int casos = 0;
    unsigned int i;
    
    casos++;
    
    if (IFS0bits.T1IF == 1){
           
        
    IFS0bits.T1IF=0;  //Limpiar FLAG de interrupcion del TMR1    
    */
    
    
    
               
   
    
    }
}//MAIN
   

