#include <p33CH512MP508.h>
#include "Func.h"

/* Este archivo contendr� la definici�n de las funciones auxiliares que se
 * necesiten para la ejecuci�n del c�digo.
 * Pueden a�adirse tantas como se quiera.
 * El objetivo es encapsular lo m�ximo posible el c�digo y reutilizar todas las+
 * funciones posibles.
 * En el archivo FUNC.H deber�n incluirse los prototipos de estas funciones.
 */

// Ejemplo:
// FUNCI�N PARA INICIALIZACI�N DE PUERTOS E/S
// Par�metros de entrada: ninguno (void).
// Par�metros de salida: ninguno (void).
void InitIO()
{
    //Configuramos leds como salidas

    TRISEbits.TRISE0 = 0;
    TRISEbits.TRISE1 = 0;
    TRISBbits.TRISB14 = 0;
    TRISDbits.TRISD7 = 0;
    TRISDbits.TRISD5 = 0;
    
// Como puse en la hoja, aqu� los inicializo al rev�s.

    LATEbits.LATE0=0;
    LATEbits.LATE1=0;
    LATBbits.LATB14=0;
    LATDbits.LATD7=0;
    LATDbits.LATD5=0;

    return;
}// InitIO

