/*
 * File:   Main.c
 * Author: SEA - Aitor VA
 * D.E.P. - GiTELE - 2019-2020
 */

/* 
 * File:   Main.c
 * Author: AVA

 */

/* Este proyecto tiene como objetivo proveer los archivos base y la estructura
 * T�pica de programaci�n para usar durante la asignatura. L�ease con atenci�n
 * las recomendaciones y las instrucciones de uso.
 */

// SIEMPRE SE INCLUIR�N ESTOS ARCHIVOS DE CABECERA:
#include "Func.h"

//---------------------------------------------------------------------------
// Global variables
//---------------------------------------------------------------------------
// En este espacio pueden declararse las variables globales o las constantes.
// Ejemplo:
// unsigned int MiValor = 0;


//---------------------------------------------------------------------------
// ISR routine
//---------------------------------------------------------------------------

// Llamada a la subrutina de interrupci�n. Descomentar estas l�neas para activarla.
// Debe incluirse el nombre de la rutina de interrupci�n (vector de interrupci�n).
// Esta llamada a la funci�n de interrupci�n debe repetirse tantas veces como
// vectores de interrupci�n haya (cada una, con su vector correspondiente)

//void __attribute__((interrupt, auto_psv)) /*NOMBRE VECTOR INTERRUPCI�N*/(void)
//{
    
//}


//---------------------------------------------------------------------------
// Main routine
//---------------------------------------------------------------------------

// Funci�n principal. Siempre incluye un bucle infinito.

int main (void)
{   
    // Aqu� se declarar�an las variables LOCALES a la funci�n Main.
    
       
    InitIO();
    
    while (1)
    {
        __delay_ms(500);
        LATEbits.LATE0 =! LATEbits.LATE0;
        LATEbits.LATE1 =! LATEbits.LATE1;
        LATBbits.LATB14 =! LATBbits.LATB14;
        LATDbits.LATD7 =! LATDbits.LATD7;
        LATDbits.LATD5 =! LATDbits.LATD5;
    }
}// Main
