/**
  Generated main.c file from MPLAB Code Configurator

  @Company
    Microchip Technology Inc.

  @File Name
    main.c

  @Summary
    This is the generated main.c using PIC24 / dsPIC33 / PIC32MM MCUs.

  @Description
    This source file provides main entry point for system initialization and application code development.
    Generation Information :
        Product Revision  :  PIC24 / dsPIC33 / PIC32MM MCUs - 1.171.1
        Device            :  dsPIC33CH512MP508
    The generated drivers are tested against the following:
        Compiler          :  XC16 v1.70
        MPLAB 	          :  MPLAB X v5.50
*/

/*
    (c) 2020 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
*/


/*________________________________________________________________________*/
// EJERCICIOS CON EL CONVERSOR ANAL�GICO DIGITAL
/*________________________________________________________________________*/



/**
  Section: Included Files
*/
#include "mcc_generated_files/system.h"
#include "mcc_generated_files/mcc.h"
#include "mcc_generated_files/pin_manager.h"
#define FCY  8000000UL
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <xc.h>
#include <libpic30.h>

#define MITAD       2048
#define M           3

/*
                         Main application
 */


unsigned int PoteCuriosity[M];      // For storing ADC output - POTEAN0
unsigned int posicion = 0;

float media;
unsigned int maximo;
unsigned int minimo;


void T1Interrupt(void)
{
    
    IFS0bits.T1IF=0;
     
    //Voy a usar la interrupci�n del timer para guardar la info del CAD
    
    ADC1_SoftwareTriggerEnable();
     
    int i;
    // Se pone siempre, debe ser por el tiempo de adquisici�n.
        for(i=0;i <1000;i++)
        {
        }
    
    ADC1_SoftwareTriggerDisable();
    
    
    //Para almacenar la conversion de lo que ve en el potenci�metro
    
    while(!ADC1_IsConversionComplete(POTEAN0));
    PoteCuriosity[posicion] = ADC1_ConversionResultGet(POTEAN0); // Este array lo usar� para las funciones ej 3
    float salida = ADC1_ConversionResultGet(POTEAN0); // Esta variable la usar� para el bur�metro.
    
     //Guardada info
    
    //FUNCIONES EJERCICIO 3
    maximo=Max(PoteCuriosity,M);
    minimo=Min(PoteCuriosity, M);
    media=Avg(PoteCuriosity,M);
    
    //BUR�METRO EJERCICIO 4
    
    //Voy a conseguir que dependiendo de c�mo est� el potenci�metro, 
    //se iluminen los leds en torno a un rango.
    
    // rangos
        
        //0-1.25 --> 1024
        //1.25-2.5 --> 2048
        //2.5-3.75 --> 3072
        //3.75-5 --> 4096
        
           
    if(salida <= 1024.0 & salida > 0.0) //se enciende el led rojo
        {
		 LATEbits.LATE0 = 0;
		 LATEbits.LATE1 = 0;
		 LATBbits.LATB14=0;
		 LATDbits.LATD7=0;
		 LATDbits.LATD5=1;
        }
        
        if(salida > 1024.0 & salida <= 2048.0) //se enciende el led 1
        {
		 LATEbits.LATE0 = 1;
		 LATEbits.LATE1 = 0;
		 LATBbits.LATB14 = 0;
		 LATDbits.LATD7=0;
		 LATDbits.LATD5=0;
        }
        
                
        if(salida > 2048.0 & salida <= 3072.0) //se enciende el led 2
        {
		 LATEbits.LATE0 = 0;
		 LATEbits.LATE1 = 1;
		 LATBbits.LATB14=0;
		 LATDbits.LATD7=0;
		 LATDbits.LATD5=0;
        }
        
                
        if(salida > 3072.0 & salida <= 4014.0) // se enciende el led azul
        {
		 LATEbits.LATE0 = 0;
		 LATEbits.LATE1 = 0;
		 LATBbits.LATB14=1;
		 LATDbits.LATD7=0;
		 LATDbits.LATD5=0;
        }
        
        if(salida>4014.0) //cuando llega al m�ximo (casi, no justo a 4095 para tener un margen) se enciende el verde.
        {
            
		 LATEbits.LATE0 = 0;
		 LATEbits.LATE1 = 0;
		 LATBbits.LATB14=0;
		 LATDbits.LATD7=1;
		 LATDbits.LATD5=0;
            
        }
    
    //Tambi�n pod�a transformar la variable salida y el bur�metro compararlo con el valor de los voltios.
    //Para el siguiente ejercicio con el LCD la variable salida ya va a ir en voltios directamente.
        
    posicion++; //C�mo hago tres conversiones y paro, Posici�n ser� menor de 3.
        if (posicion>M){
            posicion=0;
        }
        
    }
    
    
int main(void)
{
    // initialize the device
   
    SYSTEM_Initialize();
 
    //ConfigInt();

    ADC1_Initialize(); //est� en el system Initialize.
    
    ADC1_InterruptFlagClear();
    ADC1_InterruptEnable();
    
    TMR1_SetInterruptHandler(T1Interrupt);
    TMR1_Start();
    

     
    while (1)
    {
        // Add your application code
        
        
 
    }
    return 1; 
}